import asyncio
import discord


client = discord.Client()

@client.event
async def on_ready():
    print("Ich bin eingeloggt als {}".format(client.user.name))
    await client.change_presence(activity=discord.Game("Jooost"), status=discord.Status.online)

client.run("ODA3MzU1NzA0MzY4MTY5MDMw.YB2ylw.3J-6VeIgFECkWA1Se7VwJ0D9JZg")